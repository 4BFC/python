import turtle
t = turtle.Turtle()
s=["turtle","circle","square"]

t.fd(200)
t.shape(s[0])
t.stamp()
t.left(120)

t.fd(200)
t.shape(s[1])
t.stamp()
t.left(120)

t.fd(200)
t.shape(s[2])
t.stamp()
t.ht()
