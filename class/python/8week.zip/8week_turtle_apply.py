import turtle
t = turtle.Turtle()
cursor=["red","grey","blue"]
'''
t.fd(200)
t.shape("turtle")
t.color(cursor[0])
t.left(120)
t.stamp()


t.fd(200)
t.shape("turtle")
t.color(cursor[1])
t.left(120)
t.stamp()


t.fd(200)
t.shape("turtle")
t.color(cursor[2])
t.left(120)
t.stamp()

'''

t.fd(200)
t.shape("turtle")
t.color(cursor[0])
t.left(120)
t.stamp()


t.fd(200)
t.shape("turtle")
t.color(cursor[1])
t.left(120)
t.stamp()


t.fd(200)
t.shape("turtle")
t.color(cursor[2])
t.left(120)
t.stamp()

