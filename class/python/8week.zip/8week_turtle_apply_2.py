import turtle
t = turtle.Turtle()
cursor=["blue","red","grey","green"]
shape_list = ["turtle","circle","square", "classic"]

#shape/design
t.color(cursor[0])
t.shape(shape_list[0])
t.stamp()
#move
t.fd(200)
t.left(90)

#shape/design
t.color(cursor[1])
t.shape(shape_list[1])
t.stamp()
#move
t.fd(200)
t.left(90)

#shape/design
t.color(cursor[2])
t.shape(shape_list[2])
t.stamp()
#move
t.fd(200)
t.left(90)

#shape/design
t.color(cursor[3])
t.shape(shape_list[3])
t.stamp()
#move
t.fd(200)
t.ht()
