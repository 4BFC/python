colors_list= ["red","green","blue"]
print(colors_list)
print("=====================")
print(colors_list[1])
